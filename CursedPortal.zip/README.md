# CursedPortal

Cursed Valley dunyasini sunucu acilisinda yukler ve portal ile isinlanma saglar.

## Hata neden oluyor?
`cursedvalley konumuna isinlanamadi. Isinlama reddedildi` mesaji, hedef dunya
sunucuda yuklu olmadigi icin cikar. Bu plugin `load: STARTUP` ile en basta calisip
`config.yml` icindeki `auto-load-worlds` dunyalarini yukler.

## Kurulum
1. GitHub'a yukle, Actions -> Build calisinca `CursedPortal.jar` olusur (veya `mvn clean package`).
2. Jar'i `plugins/` klasorune at, sunucuyu yeniden baslat.
3. `cursedvalley` dunya klasorunun sunucu ana dizininde oldugundan emin ol.

## Komutlar (cursedportal.admin)
- `/cursedportal pos1` ve `pos2` : portal alanini sec
- `/cursedportal create <isim> <dunya>` : portal olustur
- `/cursedportal settarget <isim>` : varis noktasini bulundugun yer yap
- `/cursedportal delete|list|tp|loadworld|reload`
- `/cursedvalley` : herkes icin ana dunyaya isinlanma
