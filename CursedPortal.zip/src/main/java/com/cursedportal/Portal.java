package com.cursedportal;

import org.bukkit.Location;
import org.bukkit.World;

public class Portal {

    private final String name;
    private final String worldName;
    private final int minX, minY, minZ, maxX, maxY, maxZ;

    private String targetWorld;
    private boolean hasTarget = false;
    private double tx, ty, tz;
    private float tyaw, tpitch;

    public Portal(String name, String worldName, Location a, Location b, String targetWorld) {
        this.name = name;
        this.worldName = worldName;
        this.minX = Math.min(a.getBlockX(), b.getBlockX());
        this.minY = Math.min(a.getBlockY(), b.getBlockY());
        this.minZ = Math.min(a.getBlockZ(), b.getBlockZ());
        this.maxX = Math.max(a.getBlockX(), b.getBlockX());
        this.maxY = Math.max(a.getBlockY(), b.getBlockY());
        this.maxZ = Math.max(a.getBlockZ(), b.getBlockZ());
        this.targetWorld = targetWorld;
    }

    public Portal(String name, String worldName, int minX, int minY, int minZ,
                  int maxX, int maxY, int maxZ, String targetWorld) {
        this.name = name;
        this.worldName = worldName;
        this.minX = minX;
        this.minY = minY;
        this.minZ = minZ;
        this.maxX = maxX;
        this.maxY = maxY;
        this.maxZ = maxZ;
        this.targetWorld = targetWorld;
    }

    public boolean contains(Location loc) {
        World w = loc.getWorld();
        if (w == null || !w.getName().equals(worldName)) return false;
        int x = loc.getBlockX();
        int y = loc.getBlockY();
        int z = loc.getBlockZ();
        return x >= minX && x <= maxX && y >= minY && y <= maxY && z >= minZ && z <= maxZ;
    }

    public void setTarget(Location loc) {
        this.targetWorld = loc.getWorld().getName();
        this.hasTarget = true;
        this.tx = loc.getX();
        this.ty = loc.getY();
        this.tz = loc.getZ();
        this.tyaw = loc.getYaw();
        this.tpitch = loc.getPitch();
    }

    public void setTargetRaw(double x, double y, double z, float yaw, float pitch) {
        this.hasTarget = true;
        this.tx = x;
        this.ty = y;
        this.tz = z;
        this.tyaw = yaw;
        this.tpitch = pitch;
    }

    public String getName() { return name; }
    public String getWorldName() { return worldName; }
    public String getTargetWorld() { return targetWorld; }
    public boolean hasTarget() { return hasTarget; }
    public int getMinX() { return minX; }
    public int getMinY() { return minY; }
    public int getMinZ() { return minZ; }
    public int getMaxX() { return maxX; }
    public int getMaxY() { return maxY; }
    public int getMaxZ() { return maxZ; }
    public double getTx() { return tx; }
    public double getTy() { return ty; }
    public double getTz() { return tz; }
    public float getTyaw() { return tyaw; }
    public float getTpitch() { return tpitch; }
}
