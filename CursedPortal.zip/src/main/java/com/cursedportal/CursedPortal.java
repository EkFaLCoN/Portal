package com.cursedportal;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.WorldCreator;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

public class CursedPortal extends JavaPlugin implements Listener, CommandExecutor {

    private final Map<String, Portal> portals = new HashMap<String, Portal>();
    private final Map<UUID, Location> pos1 = new HashMap<UUID, Location>();
    private final Map<UUID, Location> pos2 = new HashMap<UUID, Location>();
    private final Map<UUID, Long> cooldowns = new HashMap<UUID, Long>();

    private File portalFile;
    private String prefix;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        prefix = color(getConfig().getString("prefix", "&8[&5CursedPortal&8] &7"));

        // Dunyalari mumkun olan en erken anda yukle (hata: "isinlama reddedildi" dunya yuklu degildi)
        loadConfiguredWorlds();

        portalFile = new File(getDataFolder(), "portals.yml");
        loadPortals();

        getServer().getPluginManager().registerEvents(this, this);
        getCommand("cursedportal").setExecutor(this);
        getCommand("cursedvalley").setExecutor(this);

        // Baska pluginler sonradan dunya yukluyorsa tekrar kontrol et
        getServer().getScheduler().runTaskLater(this, new Runnable() {
            public void run() {
                loadConfiguredWorlds();
            }
        }, 40L);
    }

    @Override
    public void onDisable() {
        savePortals();
    }

    // ---------------------------------------------------------------- dunya yukleme

    private void loadConfiguredWorlds() {
        List<String> list = getConfig().getStringList("auto-load-worlds");
        for (String name : list) {
            loadWorld(name);
        }
    }

    /** Dunyayi dondurur; yuklu degilse klasor varsa yukler (veya config izin verirse olusturur). */
    private World loadWorld(String name) {
        World w = Bukkit.getWorld(name);
        if (w != null) return w;

        File folder = new File(Bukkit.getWorldContainer(), name);
        boolean create = getConfig().getBoolean("create-if-missing", false);

        if (!folder.isDirectory() && !create) {
            getLogger().warning("'" + name + "' dunya klasoru bulunamadi: " + folder.getAbsolutePath()
                    + " (config.yml -> create-if-missing: true yaparsaniz otomatik olusturulur)");
            return null;
        }
        try {
            w = new WorldCreator(name).createWorld();
            if (w != null) getLogger().info("Dunya yuklendi: " + name);
        } catch (Exception e) {
            getLogger().warning("Dunya yuklenemedi (" + name + "): " + e.getMessage());
        }
        return w;
    }

    // ---------------------------------------------------------------- portal kayit

    private void loadPortals() {
        portals.clear();
        if (!portalFile.exists()) return;
        YamlConfiguration yml = YamlConfiguration.loadConfiguration(portalFile);
        ConfigurationSection sec = yml.getConfigurationSection("portals");
        if (sec == null) return;
        for (String key : sec.getKeys(false)) {
            ConfigurationSection s = sec.getConfigurationSection(key);
            if (s == null) continue;
            Portal p = new Portal(key, s.getString("world"),
                    s.getInt("min.x"), s.getInt("min.y"), s.getInt("min.z"),
                    s.getInt("max.x"), s.getInt("max.y"), s.getInt("max.z"),
                    s.getString("target-world"));
            if (s.getBoolean("has-target", false)) {
                p.setTargetRaw(s.getDouble("target.x"), s.getDouble("target.y"), s.getDouble("target.z"),
                        (float) s.getDouble("target.yaw"), (float) s.getDouble("target.pitch"));
            }
            portals.put(key.toLowerCase(), p);
        }
        getLogger().info(portals.size() + " portal yuklendi.");
    }

    private void savePortals() {
        YamlConfiguration yml = new YamlConfiguration();
        for (Portal p : portals.values()) {
            String b = "portals." + p.getName() + ".";
            yml.set(b + "world", p.getWorldName());
            yml.set(b + "min.x", p.getMinX());
            yml.set(b + "min.y", p.getMinY());
            yml.set(b + "min.z", p.getMinZ());
            yml.set(b + "max.x", p.getMaxX());
            yml.set(b + "max.y", p.getMaxY());
            yml.set(b + "max.z", p.getMaxZ());
            yml.set(b + "target-world", p.getTargetWorld());
            yml.set(b + "has-target", p.hasTarget());
            if (p.hasTarget()) {
                yml.set(b + "target.x", p.getTx());
                yml.set(b + "target.y", p.getTy());
                yml.set(b + "target.z", p.getTz());
                yml.set(b + "target.yaw", (double) p.getTyaw());
                yml.set(b + "target.pitch", (double) p.getTpitch());
            }
        }
        try {
            if (!getDataFolder().exists()) getDataFolder().mkdirs();
            yml.save(portalFile);
        } catch (IOException e) {
            getLogger().warning("portals.yml kaydedilemedi: " + e.getMessage());
        }
    }

    // ---------------------------------------------------------------- isinlama

    private void teleportTo(Player player, String worldName, Portal portal) {
        World w = loadWorld(worldName);
        if (w == null) {
            player.sendMessage(prefix + ChatColor.RED + "'" + worldName + "' dunyasi bulunamadi veya yuklenemedi.");
            return;
        }
        Location dest;
        if (portal != null && portal.hasTarget()) {
            dest = new Location(w, portal.getTx(), portal.getTy(), portal.getTz(), portal.getTyaw(), portal.getTpitch());
        } else {
            dest = w.getSpawnLocation().add(0.5, 0, 0.5);
        }
        if (player.teleport(dest)) {
            player.sendMessage(prefix + color(getConfig().getString("messages.teleported", "&aIsinlandin!")));
        } else {
            player.sendMessage(prefix + ChatColor.RED + "Isinlama baska bir plugin tarafindan engellendi.");
        }
    }

    @EventHandler
    public void onMove(PlayerMoveEvent e) {
        Location from = e.getFrom();
        Location to = e.getTo();
        if (to == null) return;
        if (from.getBlockX() == to.getBlockX() && from.getBlockY() == to.getBlockY()
                && from.getBlockZ() == to.getBlockZ() && from.getWorld() == to.getWorld()) return;

        Player p = e.getPlayer();
        if (!p.hasPermission("cursedportal.use")) return;

        for (Portal portal : portals.values()) {
            if (portal.contains(to)) {
                long now = System.currentTimeMillis();
                Long last = cooldowns.get(p.getUniqueId());
                long cd = getConfig().getLong("cooldown-seconds", 3) * 1000L;
                if (last != null && now - last < cd) return;
                cooldowns.put(p.getUniqueId(), now);
                teleportTo(p, portal.getTargetWorld(), portal);
                return;
            }
        }
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        UUID id = e.getPlayer().getUniqueId();
        cooldowns.remove(id);
        pos1.remove(id);
        pos2.remove(id);
    }

    // ---------------------------------------------------------------- komutlar

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        // /cursedvalley -> direkt isinla
        if (cmd.getName().equalsIgnoreCase("cursedvalley")) {
            if (!(sender instanceof Player)) {
                sender.sendMessage("Bu komut sadece oyuncular icindir.");
                return true;
            }
            Player p = (Player) sender;
            if (!p.hasPermission("cursedportal.use")) {
                p.sendMessage(prefix + ChatColor.RED + "Yetkin yok.");
                return true;
            }
            teleportTo(p, getConfig().getString("main-world", "cursedvalley"), null);
            return true;
        }

        if (!sender.hasPermission("cursedportal.admin")) {
            sender.sendMessage(prefix + ChatColor.RED + "Yetkin yok.");
            return true;
        }

        if (args.length == 0) {
            help(sender);
            return true;
        }

        String sub = args[0].toLowerCase();

        if (sub.equals("reload")) {
            reloadConfig();
            prefix = color(getConfig().getString("prefix", "&8[&5CursedPortal&8] &7"));
            loadConfiguredWorlds();
            loadPortals();
            sender.sendMessage(prefix + "Yeniden yuklendi.");
            return true;
        }

        if (sub.equals("list")) {
            sender.sendMessage(prefix + "Portallar (" + portals.size() + "):");
            for (Portal p : portals.values()) {
                sender.sendMessage(ChatColor.GRAY + " - " + ChatColor.LIGHT_PURPLE + p.getName()
                        + ChatColor.GRAY + " [" + p.getWorldName() + "] -> " + p.getTargetWorld());
            }
            return true;
        }

        if (sub.equals("loadworld")) {
            if (args.length < 2) {
                sender.sendMessage(prefix + "Kullanim: /" + label + " loadworld <dunya>");
                return true;
            }
            World w = loadWorld(args[1]);
            sender.sendMessage(prefix + (w != null ? ChatColor.GREEN + "Dunya hazir: " + w.getName()
                    : ChatColor.RED + "Dunya yuklenemedi (klasor yok olabilir)."));
            return true;
        }

        if (sub.equals("delete")) {
            if (args.length < 2) {
                sender.sendMessage(prefix + "Kullanim: /" + label + " delete <isim>");
                return true;
            }
            if (portals.remove(args[1].toLowerCase()) != null) {
                savePortals();
                sender.sendMessage(prefix + "Portal silindi.");
            } else {
                sender.sendMessage(prefix + ChatColor.RED + "Portal bulunamadi.");
            }
            return true;
        }

        // Asagidaki komutlar oyuncu gerektirir
        if (!(sender instanceof Player)) {
            sender.sendMessage("Bu komut sadece oyuncular icindir.");
            return true;
        }
        Player p = (Player) sender;

        if (sub.equals("pos1")) {
            pos1.put(p.getUniqueId(), p.getLocation().getBlock().getLocation());
            p.sendMessage(prefix + "Pozisyon 1 ayarlandi.");
            return true;
        }
        if (sub.equals("pos2")) {
            pos2.put(p.getUniqueId(), p.getLocation().getBlock().getLocation());
            p.sendMessage(prefix + "Pozisyon 2 ayarlandi.");
            return true;
        }

        if (sub.equals("create")) {
            if (args.length < 3) {
                p.sendMessage(prefix + "Kullanim: /" + label + " create <isim> <hedef-dunya>");
                return true;
            }
            Location a = pos1.get(p.getUniqueId());
            Location b = pos2.get(p.getUniqueId());
            if (a == null || b == null) {
                p.sendMessage(prefix + ChatColor.RED + "Once /" + label + " pos1 ve pos2 ile alani sec.");
                return true;
            }
            if (!a.getWorld().equals(b.getWorld())) {
                p.sendMessage(prefix + ChatColor.RED + "Iki pozisyon ayni dunyada olmali.");
                return true;
            }
            Portal portal = new Portal(args[1], a.getWorld().getName(), a, b, args[2]);
            portals.put(args[1].toLowerCase(), portal);
            savePortals();
            p.sendMessage(prefix + ChatColor.GREEN + "Portal olusturuldu: " + args[1] + " -> " + args[2]);
            return true;
        }

        if (sub.equals("settarget")) {
            if (args.length < 2) {
                p.sendMessage(prefix + "Kullanim: /" + label + " settarget <portal>");
                return true;
            }
            Portal portal = portals.get(args[1].toLowerCase());
            if (portal == null) {
                p.sendMessage(prefix + ChatColor.RED + "Portal bulunamadi.");
                return true;
            }
            portal.setTarget(p.getLocation());
            savePortals();
            p.sendMessage(prefix + ChatColor.GREEN + "Hedef konum bulundugun yer olarak ayarlandi.");
            return true;
        }

        if (sub.equals("tp")) {
            if (args.length < 2) {
                p.sendMessage(prefix + "Kullanim: /" + label + " tp <dunya>");
                return true;
            }
            teleportTo(p, args[1], null);
            return true;
        }

        help(sender);
        return true;
    }

    private void help(CommandSender s) {
        s.sendMessage(ChatColor.DARK_PURPLE + "=== CursedPortal ===");
        s.sendMessage(ChatColor.LIGHT_PURPLE + "/cursedportal pos1 / pos2" + ChatColor.GRAY + " - portal alanini sec");
        s.sendMessage(ChatColor.LIGHT_PURPLE + "/cursedportal create <isim> <dunya>" + ChatColor.GRAY + " - portal olustur");
        s.sendMessage(ChatColor.LIGHT_PURPLE + "/cursedportal settarget <isim>" + ChatColor.GRAY + " - varis noktasini bulundugun yer yap");
        s.sendMessage(ChatColor.LIGHT_PURPLE + "/cursedportal delete <isim>" + ChatColor.GRAY + " - portal sil");
        s.sendMessage(ChatColor.LIGHT_PURPLE + "/cursedportal list" + ChatColor.GRAY + " - portallari listele");
        s.sendMessage(ChatColor.LIGHT_PURPLE + "/cursedportal tp <dunya>" + ChatColor.GRAY + " - dunyaya isinlan");
        s.sendMessage(ChatColor.LIGHT_PURPLE + "/cursedportal loadworld <dunya>" + ChatColor.GRAY + " - dunyayi yukle");
        s.sendMessage(ChatColor.LIGHT_PURPLE + "/cursedportal reload" + ChatColor.GRAY + " - yeniden yukle");
        s.sendMessage(ChatColor.LIGHT_PURPLE + "/cursedvalley" + ChatColor.GRAY + " - ana dunyaya isinlan");
    }

    private static String color(String s) {
        return ChatColor.translateAlternateColorCodes('&', s);
    }
}
